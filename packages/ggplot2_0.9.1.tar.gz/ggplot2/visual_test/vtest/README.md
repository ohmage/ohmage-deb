This repository contains the results of visual tests for `ggplot2`, generated using the `vtest` package.
